package br.com.diaadiaatm.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.PrintManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** Um WebView para o site original, com links de WhatsApp abertos DIRETAMENTE no app. */
public final class MainActivity extends Activity {
    private static final String SITE = "https://visionary-hamster-5127a9.netlify.app/";
    private static final String SITE_HOST = "visionary-hamster-5127a9.netlify.app";
    private static final int PICK_FILE = 2401;

    private WebView web;
    private ValueCallback<Uri[]> pendingFileChooser;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10, 21, 35));
        getWindow().setNavigationBarColor(Color.rgb(10, 21, 35));

        FrameLayout container = new FrameLayout(this);
        container.setBackgroundColor(Color.rgb(10, 21, 35));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(10, 21, 35));
        container.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(container);

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new NativeActions(), "ATMNative");

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                return routeLink(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeLink(Uri.parse(url));
            }
            @Override public void onPageFinished(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (SITE_HOST.equalsIgnoreCase(uri.getHost())) {
                    installWhatsAppCompatibility();
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                    ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
                pendingFileChooser = callback;
                try {
                    Intent picker = params.createIntent();
                    startActivityForResult(picker, PICK_FILE);
                    return true;
                } catch (Exception ex) {
                    pendingFileChooser = null;
                    toast("Não foi possível abrir os arquivos.");
                    return false;
                }
            }
        });

        web.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent,
                    String contentDisposition, String mimeType, long contentLength) {
                if (url.startsWith("blob:")) {
                    downloadBlob(url, mimeType);
                } else if (url.startsWith("https://")) {
                    downloadHttps(url, mimeType, contentDisposition);
                } else {
                    toast("Formato de download indisponível.");
                }
            }
        });

        if (savedInstanceState == null) {
            web.loadUrl(SITE);
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    /** Nunca usa ACTION_SEND ou Intent.createChooser: isso abriria o menu Compartilhar. */
    private boolean routeLink(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();

        if ("whatsapp".equals(scheme) || "wa.me".equals(host)
                || "api.whatsapp.com".equals(host) || "www.whatsapp.com".equals(host)) {
            openWhatsApp(uri.getQueryParameter("text"));
            return true;
        }

        if (("https".equals(scheme) || "http".equals(scheme))
                && !SITE_HOST.equals(host)) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            } catch (ActivityNotFoundException ex) {
                toast("Não foi possível abrir o link.");
            }
            return true;
        }
        return false;
    }

    private void openWhatsApp(String text) {
        final String safeText = text == null ? "" : text;
        Uri deepLink = Uri.parse("whatsapp://send?text=" + Uri.encode(safeText));
        // setPackage força a abertura do WhatsApp instalado; sem lista de compartilhamento.
        for (String packageName : new String[] {"com.whatsapp", "com.whatsapp.w4b"}) {
            Intent direct = new Intent(Intent.ACTION_VIEW, deepLink);
            direct.setPackage(packageName);
            direct.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(direct);
                return;
            } catch (ActivityNotFoundException ignored) {
                // Tenta a outra edição do WhatsApp.
            } catch (SecurityException ignored) {
                // No caso de um aparelho restringir a edição instalada.
            }
        }
        // Fallback apenas se nenhuma das duas versões estiver disponível.
        try {
            Uri fallback = Uri.parse("https://wa.me/?text=" + Uri.encode(safeText));
            startActivity(new Intent(Intent.ACTION_VIEW, fallback));
        } catch (ActivityNotFoundException ex) {
            toast("Instale o WhatsApp para enviar a mensagem.");
        }
    }

    /** Suporte a versões em cache do site que ainda chamam navigator.share/window.open. */
    private void installWhatsAppCompatibility() {
        String script = "(function(){"
                + "try{Object.defineProperty(navigator,'share',{configurable:true,value:function(d){"
                + "if(d&&d.text){ATMNative.openWhatsAppText(d.text);return Promise.resolve();}"
                + "return Promise.reject(new Error('Sem texto'));}});}catch(e){}"
                + "var oldOpen=window.open;window.open=function(u){"
                + "if(typeof u==='string'&&/^https:\\/\\/(wa\\.me|api\\.whatsapp\\.com)\\//i.test(u)){"
                + "ATMNative.openWhatsAppUrl(u);return window;}"
                + "return oldOpen.apply(window,arguments);};"
                + "window.print=function(){ATMNative.printNow();};"
                + "})();";
        web.evaluateJavascript(script, null);
    }

    private void downloadBlob(String url, String mime) {
        String js = "(async function(){try{const resp=await fetch(" + JSONObject.quote(url)
                + ");const blob=await resp.blob();const reader=new FileReader();"
                + "reader.onloadend=function(){ATMNative.saveBase64(reader.result,'atm-download.txt',"
                + JSONObject.quote(mime == null ? "text/plain" : mime) + ");};"
                + "reader.readAsDataURL(blob);}catch(e){ATMNative.showMessage('Falha ao baixar arquivo');}})();";
        web.evaluateJavascript(js, null);
    }

    private void downloadHttps(String url, String mime, String disposition) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle("Dia a Dia do ATM");
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    URLUtil.guessFileName(url, disposition, mime));
            if (mime != null) request.setMimeType(mime);
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            manager.enqueue(request);
            toast("Download iniciado.");
        } catch (Exception ex) {
            toast("Não foi possível iniciar o download.");
        }
    }

    private void writeDownload(String base64, String suggestedName, String mime) {
        try {
            String cleanName = suggestedName.replaceAll("[^\\p{L}\\p{N}._-]", "_");
            if (cleanName.isEmpty()) cleanName = "registro-atm.txt";
            String content = base64.substring(base64.indexOf(',') + 1);
            byte[] bytes = Base64.decode(content, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, cleanName);
                values.put(MediaStore.Downloads.MIME_TYPE,
                        mime == null || mime.isEmpty() ? "text/plain" : mime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri target = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (target == null) throw new IllegalStateException("Sem pasta Downloads");
                try (OutputStream out = getContentResolver().openOutputStream(target)) {
                    if (out == null) throw new IllegalStateException("Sem saída");
                    out.write(bytes);
                }
            } else {
                File file = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), cleanName);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(bytes);
                }
            }
            toast("Arquivo salvo: " + cleanName);
        } catch (Exception ex) {
            toast("Falha ao salvar o arquivo.");
        }
    }

    private void toast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    private final class NativeActions {
        @JavascriptInterface public void openWhatsAppText(String text) {
            runOnUiThread(() -> openWhatsApp(text));
        }
        @JavascriptInterface public void openWhatsAppUrl(String url) {
            runOnUiThread(() -> routeLink(Uri.parse(url)));
        }
        @JavascriptInterface public void saveBase64(String base64, String name, String mime) {
            writeDownload(base64, name, mime);
        }
        @JavascriptInterface public void printNow() {
            runOnUiThread(() -> {
                PrintManager print = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                print.print("Dia a Dia do ATM", web.createPrintDocumentAdapter("Dia a Dia do ATM"),
                        new PrintAttributes.Builder().build());
            });
        }
        @JavascriptInterface public void showMessage(String message) {
            toast(message);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && pendingFileChooser != null) {
            pendingFileChooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            pendingFileChooser = null;
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        web.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("ATMNative");
            web.destroy();
        }
        super.onDestroy();
    }
}
