/* Ajustes do fluxo de encerramento: Escalado, Livro e Procedimento de Baixa. */
(function () {
  'use strict';
  if (window.__atmWorkflowV4 || typeof TOPICS === 'undefined' ||
      typeof renderForm !== 'function' || typeof bindFields !== 'function' ||
      typeof whatsappFormatted !== 'function' || typeof read !== 'function') return;
  window.__atmWorkflowV4 = true;

  const renderBefore = window.renderForm;
  const bindBefore = window.bindFields;
  const formatBefore = window.whatsappFormatted;
  const affected = new Set(['scheduled', 'book', 'leave']);
  const topicAt = index => TOPICS[index] && TOPICS[index].type;
  const clone = value => JSON.parse(JSON.stringify(value));
  let lastUndo = null;

  function currentUndo() {
    if (!lastUndo) return;
    const d = read(lastUndo.index);
    for (const key of Object.keys(d)) delete d[key];
    Object.assign(d, clone(lastUndo.data));
    const index = lastUndo.index;
    lastUndo = null;
    persist(index, d);
    open(index);
    updateUndoButton();
    if (typeof toast === 'function') toast('Registro anterior restaurado.');
  }

  function updateUndoButton() {
    let button = document.getElementById('atm-undo-floating');
    if (!button && document.body && document.createElement) {
      button = document.createElement('button');
      button.id = 'atm-undo-floating';
      button.type = 'button';
      button.textContent = '↶ Reverter último registro';
      button.style.cssText = 'position:fixed;bottom:calc(82px + env(safe-area-inset-bottom));right:14px;'+
        'z-index:99999;background:#fff9dd;color:#49310d;border:2px solid #e7b849;'+
        'border-radius:16px;box-shadow:0 4px 22px #0005;padding:12px 15px;'+
        'font:700 14px system-ui,sans-serif;max-width:85vw;cursor:pointer';
      button.onclick = currentUndo;
      document.body.appendChild(button);
    }
    if (button) button.hidden = !lastUndo;
    const inline = document.getElementById('atm-undo-inline');
    if (inline) inline.onclick = currentUndo;
  }

  function resetAfterSuccess(index) {
    const type = topicAt(index);
    if (!affected.has(type)) return;
    const d = read(index);
    lastUndo = {index, data: clone(d)};
    if (type === 'scheduled') {
      // Preserva texto fixo/adicional, turno e data; retira somente as escolhas FA/FT.
      d.scheduledEntries = [];
    } else if (type === 'book') {
      // Equipe, material e dados fixos continuam disponíveis para o plantão seguinte.
      d.incidents = [];
      d.kmStart = '';
      d.kmEnd = '';
      d.includeRonda = false;
      d.includeMovement = false;
      d.checklist = {};
    } else if (type === 'leave') {
      for (const key of ['name','re','coverName','coverRe','shift','shiftCustom','start','end']) d[key] = '';
      d.date = todayDate();
    }
    persist(index, d);
    if (current === index) open(index);
    updateUndoButton();
  }

  function leaveMessage(d) {
    const n = daysInclusive(d.start, d.end);
    const rawShift = effectiveShift(d);
    const match = typeof SHIFT_OPTIONS === 'undefined' ? null :
      SHIFT_OPTIONS.find(opt => opt[0] === normalizeShift(d.shift));
    const shift = match && normalizeShift(d.shift) !== 'OUTRO' ? match[1] : rawShift;
    return '*PROCEDIMENTO DE BAIXA – ' + dateBR(d.date) + '*\n\n' +
      '● Colaborador: ' + (String(d.name || '').trim() || '[nome]') + '\n' +
      'Escala: ' + shift + '\n\n' +
      '● Período de afastamento: ' + dateBR(d.start) + ' a ' + dateBR(d.end) + '\n\n' +
      '● Total de dias afastado: ' + (n === null ? 'Verificar datas' :
      String(n).padStart(2,'0') + ' ' + (n === 1 ? 'dia' : 'dias'));
  }

  window.whatsappFormatted = function (index, d) {
    if (topicAt(index) === 'leave') return leaveMessage(d);
    return formatBefore.call(this, index, d);
  };

  window.renderForm = function (index, d) {
    const type = topicAt(index);
    // O modelo antigo trazia 51. pré-escrito mesmo antes de digitar.
    if (type === 'book') {
      for (const key of ['kmStart','kmEnd']) if (d[key] === '51.') d[key] = '';
    }
    let html = renderBefore.call(this, index, d);
    if (type === 'book') {
      html = html.replace('Já começa com 51. — digite o restante, por exemplo 020.',
        'Digite a quilometragem; os pontos aparecem automaticamente. Ex.: 51500 → 51.500.');
      html = html.replace('O início 51. já está preenchido; os dois primeiros dígitos também podem ser corrigidos quando necessário.',
        'Informe a quilometragem final sem pontos; ela será formatada automaticamente.');
    }
    if (type === 'leave') {
      // Mantém os inputs ocultos somente para compatibilidade com o cadastro legado.
      html = html.replace('<h4>Funcionário afastado (FA)</h4>', '<h4>Colaborador afastado</h4>');
      html = html.replace('<div class="subsection"><h4>Funcionário que fará a cobertura (FT)</h4>',
        '<div class="subsection" hidden><h4>Funcionário que fará a cobertura (FT)</h4>');
    }
    if (affected.has(type) && lastUndo && lastUndo.index === index) {
      html += '<div class="inline-actions"><button id="atm-undo-inline" type="button" '+
        'class="btn secondary">↶ Reverter último registro copiado</button></div>';
    }
    return html;
  };

  function formatThousands(s) {
    const digits = String(s == null ? '' : s).replace(/\D/g,'');
    return digits.replace(/\B(?=(\d{3})+(?!\d))/g,'.');
  }

  window.bindFields = function (d) {
    bindBefore.call(this, d);
    if (topicAt(current) === 'book') {
      for (const key of ['kmStart','kmEnd']) {
        const el = document.getElementById('f-' + key);
        if (!el) continue;
        el.setAttribute('inputmode','numeric');
        el.value = formatThousands(d[key]);
        el.addEventListener('input', () => {
          const formatted = formatThousands(el.value);
          if (el.value !== formatted || d[key] !== formatted) {
            el.value = formatted;
            d[key] = formatted;
            persist(current, d);
            updatePreview(d);
          }
        });
      }
    }
    updateUndoButton();
  };

  // Copiar precisa retornar sucesso; nunca limpamos o texto se a cópia falhar.
  async function copyAndReset(closeAfter) {
    const index = current;
    if (index < 0 || typeof copyText !== 'function') return;
    const copied = await copyText();
    if (!copied) return;
    resetAfterSuccess(index);
    if (closeAfter) open(-1);
    updateUndoButton();
  }

  for (const id of ['copyBtn','copyMainBtn','copyCloseBtn']) {
    const button = document.getElementById(id);
    if (button) button.onclick = () => copyAndReset(id === 'copyCloseBtn');
  }
  const whatsapp = document.getElementById('whatsAppBtn');
  if (whatsapp) {
    const shareBefore = whatsapp.onclick;
    whatsapp.onclick = function (ev) {
      const index = current;
      if (typeof shareBefore === 'function') shareBefore.call(this, ev);
      if (affected.has(topicAt(index))) resetAfterSuccess(index);
    };
  }
  updateUndoButton();
})();
