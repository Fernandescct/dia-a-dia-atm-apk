# Dia a Dia do ATM — APK com WhatsApp direto

WebView Android para `https://visionary-hamster-5127a9.netlify.app/`, sem alterar o site.

- O botão WhatsApp abre `whatsapp://send` diretamente no app instalado, preenchendo o texto da mensagem. Não usa `Intent.ACTION_SEND`, `Intent.createChooser` nem o menu **Compartilhar**.
- Suporta WhatsApp comum (`com.whatsapp`) e WhatsApp Business (`com.whatsapp.w4b`); sem ambos, oferece link HTTPS como alternativa.
- Preserva o site e seus recursos de formulários, navegação, impressão, seleção de arquivos e download de texto.
- Usa ID de pacote diferente da versão anterior para permitir teste lado a lado, sem desinstalação ou perda de dados.
- O APK de teste terá assinatura de debug; não é versão de loja.

## Build

Gradle 8.9, JDK 17, Android Gradle Plugin 8.7.3, Android SDK 35.

Na pasta deste projeto: `gradle :app:assembleDebug`.

Em GitHub Actions, o APK é gerado e anexado como artefato; o workflow também publica um pré-lançamento GitHub com o APK.

## Verificações

O build e o roteamento de links podem ser revisados automaticamente. A abertura real do WhatsApp precisa de confirmação em Android com WhatsApp instalado, antes de chamar a versão de estável.
