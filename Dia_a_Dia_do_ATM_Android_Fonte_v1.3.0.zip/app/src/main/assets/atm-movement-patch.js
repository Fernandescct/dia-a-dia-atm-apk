(function () {
  'use strict';
  if (window.__atmMovementV3 || typeof TOPICS === 'undefined' ||
      typeof renderForm !== 'function' || typeof bindFields !== 'function' ||
      typeof whatsappFormatted !== 'function') return;
  window.__atmMovementV3 = true;

  const renderBefore = window.renderForm;
  const bindBefore = window.bindFields;
  const whatsappBefore = window.whatsappFormatted;
  const nativeScheduled = typeof ATMAdvanced !== 'undefined' && ATMAdvanced.setupScheduled;
  const getTopic = index => TOPICS[index] && TOPICS[index].type;
  const pairToken = () => 'atm-pair-' + Date.now() + '-' + Math.random().toString(36).slice(2, 9);
  const asText = x => String(x == null ? '' : x).trim();
  const selected = (actual, value) => actual === value ? ' selected' : '';

  function period(d) {
    return d.period === 'DIURNO' ? 'DIURNO' : 'NOTURNO';
  }

  function shiftLabels(d) {
    const day = period(d) === 'DIURNO';
    const parity = day && /^(IMPAR|PAR)$/.test(d.parity || '') ? ' ' + d.parity : '';
    return {
      a: 'EFETIVO 12x36 ' + (day ? 'DIURNO' : 'NOTURNO') + parity,
      b: 'EFETIVO 6x1 ' + (day ? 'MANHÃ' : 'TARDE'),
      c: day ? 'GALPÃO DO PADRE ZÉ' : 'GALPÃO PADRE ZÉ'
    };
  }

  function line(e) {
    const type = e.type === 'CONVOCACAO' ? 'CONVOCAÇÃO' : (e.type === 'FT' ? 'FT' : 'FA');
    return type + '. RE: ' + (asText(e.re) || '[CONFERIR RE]') + ', ' +
      (asText(e.name).toUpperCase() || '[INFORMAR NOME]') + '.';
  }

  function sectorLines(d, key, legacyKey, detailKey) {
    const entries = Array.isArray(d[key]) ? d[key] : [];
    if (entries.length) return entries.map(line).join('\n');
    return d[legacyKey] && d[legacyKey] !== 'OK' ?
      (asText(d[detailKey]) || d[legacyKey]) : 'OK';
  }

  function createMovementText(d, bold) {
    const daytime = period(d) === 'DIURNO';
    const labels = shiftLabels(d);
    const heavy = text => bold ? '*' + text + '*' : text;
    const group = (label, key, legacy, detail) => {
      const txt = sectorLines(d, key, legacy, detail);
      return heavy(label) + (txt === 'OK' ? ' OK' : '\n\n' + txt);
    };
    const greeting = daytime ? 'Bom dia a todos !' : 'Boa noite senhores!';
    const when = daytime ? 'DIURNAS' : 'NOTURNAS';
    const institution = 'FACULDADE CRUZEIRO DO SUL/UNIPÊ-PB.';
    const sign = asText(d.sign) || 'ATM MARINALDO FERNANDES';
    const other = asText(d.other) || 'DEMAIS POSTOS ESTÃO COBERTOS SEM ALTERAÇÕES ATÉ O MOMENTO';
    return [
      greeting, '',
      'Segue as movimentações ' + heavy(when) + ' de hoje ' + dateBR(d.date) + '.', '',
      heavy(institution), '',
      group(labels.a, 'entries12', 's12', 'd12'), '',
      group(labels.b, 'entries6', 's6', 'd6'), '',
      group(labels.c, 'entriesGalpao', 'galpao', 'dg'), '',
      heavy(other), '',
      heavy(sign), '',
      heavy('Faculdade Cruzeiro do Sul /Unipê-PB')
    ].join('\n');
  }

  window.movementText = function (d) { return createMovementText(d, false); };
  window.whatsappFormatted = function (index, d) {
    if (getTopic(index) === 'movement') return createMovementText(d, true);
    return whatsappBefore.call(this, index, d);
  };

  window.renderForm = function (index, d) {
    let html = renderBefore.call(this, index, d);
    if (getTopic(index) === 'movement') {
      const day = period(d);
      const periodSelector = '<div class="grid">' +
        '<div class="field"><label for="f-period">Período da movimentação</label>' +
        '<select id="f-period" data-key="period">' +
        '<option value="NOTURNO"' + selected(day, 'NOTURNO') + '>Noturno</option>' +
        '<option value="DIURNO"' + selected(day, 'DIURNO') + '>Diurno</option></select></div>' +
        '<div class="field" id="atm-parity-field"' + (day !== 'DIURNO' ? ' hidden' : '') + '>' +
        '<label for="f-parity">Escala 12x36</label>' +
        '<select id="f-parity" data-key="parity">' +
        '<option value="">Sem indicação de paridade</option>' +
        '<option value="IMPAR"' + selected(d.parity, 'IMPAR') + '>Ímpar</option>' +
        '<option value="PAR"' + selected(d.parity, 'PAR') + '>Par</option></select></div></div>';
      html = html.replace(
        '<div class="subsection"><h4>Efetivo e ocorrências de pessoal</h4>',
        periodSelector + '<div class="subsection"><h4>Efetivo e ocorrências de pessoal</h4>'
      );
      html = html.replace(
        'Adicione FA para uma falta e FT para quem está cobrindo.',
        'Ao incluir FA ou Convocação, o FT correspondente aparece automaticamente.'
      );
      for (const key of ['entries12', 'entries6', 'entriesGalpao']) {
        const button = '<button type="button" class="btn secondary" data-add-ft="' + key + '">';
        html = html.replace(button,
          '<button type="button" class="btn secondary" data-add-conv="' + key +
          '">+ Convocação</button>' + button);
      }
    }
    if (getTopic(index) === 'scheduled') {
      html = html.replace(
        'Escolha FA ou FT, digite o nome e o RE aparecerá automaticamente.',
        'FA e Convocação incluem automaticamente um FT para cobertura. O RE é preenchido pelo cadastro.'
      );
      const button = '<button type="button" class="btn secondary" id="scheduledAddFT">';
      html = html.replace(button,
        '<button type="button" class="btn secondary" id="scheduledAddCONV">+ Convocação</button>' + button);
    }
    if (getTopic(index) === 'find') {
      html = html.replace(
        '<select id="f-who" data-key="who">',
        '<select id="f-who" data-key="who"><option value="">Selecione a empresa</option>'
      );
      html += '<div class="inline-actions"><button type="button" class="btn secondary" ' +
        'id="atm-new-found">+ Novo registro (limpar ficha)</button></div>';
    }
    return html;
  };

  // As duas fichas fazem o RE acompanhar o nome, sem adivinhar quem dará cobertura.
  function newAbsence(list, type) {
    const token = pairToken();
    list.push({type, name:'', re:'', pair:token});
    list.push({type:'FT', name:'', re:'', pair:token});
  }
  function rowMarkup(row, i, key, prefix) {
    const kind = row.type === 'CONVOCACAO' ? 'CONVOCAÇÃO' : row.type;
    const absence = row.type !== 'FT';
    const dataName = prefix === 'm' ? 'data-person="' + key + '" data-row="' + i + '"' : 'data-sname="' + i + '"';
    const dataRE = prefix === 'm' ? 'data-re="' + key + '" data-row="' + i + '"' : 'data-sre="' + i + '"';
    const dataDel = prefix === 'm' ? 'data-del="' + key + '" data-row="' + i + '"' : 'data-sdelete="' + i + '"';
    const list = prefix === 'm' ? 'movement-directory' : 'scheduledDirectory';
    return '<div class="movement-person">' +
      '<span class="movement-kind ' + (absence ? 'absence' : 'coverage') + '">' + kind + '</span>' +
      '<div class="field"><label>Colaborador</label><input type="text" list="' + list + '" ' + dataName +
      ' value="' + escapeHTML(row.name || '') + '" placeholder="Comece a digitar o nome..." autocomplete="off"></div>' +
      '<div class="field"><label>RE automático</label><input type="text" ' + dataRE +
      ' value="' + escapeHTML(row.re || '') + '" placeholder="RE"></div>' +
      '<button type="button" class="mini-btn danger" ' + dataDel +
      ' aria-label="Remover ' + (row.pair ? 'dupla' : kind) + '">✕</button></div>';
  }
  function erasePair(list, index) {
    const pair = list[index] && list[index].pair;
    if (!pair) list.splice(index, 1);
    else for (let i = list.length - 1; i >= 0; i--) {
      if (list[i].pair === pair) list.splice(i, 1);
    }
  }

  window.setupMovement = function (d) {
    const sectors = [['entries12','s12','d12'], ['entries6','s6','d6'], ['entriesGalpao','galpao','dg']];
    const directory = document.createElement('datalist');
    directory.id = 'movement-directory';
    directory.innerHTML = roster().map(r => '<option value="' + escapeHTML(r.name) +
      '" label="RE: ' + escapeHTML(r.re) + '"></option>').join('');
    $('form-area').appendChild(directory);
    function show(key) {
      const sector = document.querySelector('[data-sector="' + key + '"]');
      const list = $('rows-' + key);
      const rows = d[key] || [];
      sector.querySelector('.sector-state').textContent = rows.length ?
        rows.filter(x => x.type === 'FA').length + ' FA · ' +
        rows.filter(x => x.type === 'CONVOCACAO').length + ' Conv. · ' +
        rows.filter(x => x.type === 'FT').length + ' FT' : 'OK';
      list.innerHTML = rows.map((r,i) => rowMarkup(r,i,key,'m')).join('');
      list.querySelectorAll('[data-person]').forEach(el => el.oninput = () => {
        const row = d[key][+el.dataset.row];
        row.name = el.value;
        row.re = lookupColleague(el.value)?.re || '';
        list.querySelector('[data-re="' + key + '"][data-row="' + el.dataset.row + '"]').value = row.re;
        persist(current,d); updatePreview(d);
      });
      list.querySelectorAll('[data-re]').forEach(el => el.oninput = () => {
        d[key][+el.dataset.row].re = el.value; persist(current,d); updatePreview(d);
      });
      list.querySelectorAll('[data-del]').forEach(el => el.onclick = () => {
        erasePair(d[key], +el.dataset.row);
        persist(current,d); show(key); updatePreview(d);
      });
    }
    for (const [key,status,detail] of sectors) {
      if (!Array.isArray(d[key])) d[key] = [];
      if (!d[key].length && d[status] !== 'OK' && asText(d[detail])) {
        d[key].push({type: d[status] === 'FT' ? 'FT' : 'FA',name:d[detail],re:''});
        d[status] = 'OK'; d[detail] = ''; persist(current,d);
      }
      const add = type => {
        if (type === 'FT') d[key].push({type:'FT',name:'',re:''});
        else newAbsence(d[key],type);
        d[status] = 'OK'; d[detail] = '';
        persist(current,d); show(key); updatePreview(d);
        const first = $('rows-' + key).querySelectorAll('[data-person]');
        first[type === 'FT' ? first.length - 1 : first.length - 2]?.focus();
      };
      document.querySelector('[data-add-fa="' + key + '"]').onclick = () => add('FA');
      document.querySelector('[data-add-conv="' + key + '"]').onclick = () => add('CONVOCACAO');
      document.querySelector('[data-add-ft="' + key + '"]').onclick = () => add('FT');
      document.querySelector('[data-clear="' + key + '"]').onclick = () => {
        if (d[key].length && !confirm('Marcar este setor como OK e remover FA, Convocação e FT?')) return;
        d[key] = []; d[status] = 'OK'; d[detail] = '';
        persist(current,d); show(key); updatePreview(d);
      };
      show(key);
    }
  };

  if (typeof ATMAdvanced !== 'undefined' && nativeScheduled) {
    ATMAdvanced.scheduledLines = function (d) {
      const rows = Array.isArray(d.scheduledEntries) ? d.scheduledEntries : [];
      return rows.map(line).concat(asText(d.lines) ? [asText(d.lines)] : []).join('\n');
    };
    ATMAdvanced.setupScheduled = function (d) {
      if (!Array.isArray(d.scheduledEntries)) d.scheduledEntries = [];
      const holder = $('scheduledRows');
      if (!holder) return;
      const directory = document.createElement('datalist');
      directory.id = 'scheduledDirectory';
      directory.innerHTML = roster().map(r => '<option value="' + escapeHTML(r.name) +
        '" label="RE: ' + escapeHTML(r.re) + '"></option>').join('');
      $('form-area').appendChild(directory);
      const draw = () => {
        holder.innerHTML = d.scheduledEntries.map((r,i) => rowMarkup(r,i,'','s')).join('');
        holder.querySelectorAll('[data-sname]').forEach(el => el.oninput = () => {
          const row = d.scheduledEntries[+el.dataset.sname];
          row.name = el.value; row.re = lookupColleague(el.value)?.re || '';
          holder.querySelector('[data-sre="' + el.dataset.sname + '"]').value = row.re;
          persist(current,d); updatePreview(d);
        });
        holder.querySelectorAll('[data-sre]').forEach(el => el.oninput = () => {
          d.scheduledEntries[+el.dataset.sre].re = el.value; persist(current,d); updatePreview(d);
        });
        holder.querySelectorAll('[data-sdelete]').forEach(el => el.onclick = () => {
          erasePair(d.scheduledEntries,+el.dataset.sdelete);
          persist(current,d); draw(); updatePreview(d);
        });
      };
      for (const [type,id] of [['FA','scheduledAddFA'],['CONVOCACAO','scheduledAddCONV'],['FT','scheduledAddFT']]) {
        const button = $(id);
        if (!button) continue;
        button.onclick = () => {
          if (type === 'FT') d.scheduledEntries.push({type:'FT',name:'',re:''});
          else newAbsence(d.scheduledEntries,type);
          persist(current,d); draw(); updatePreview(d);
          const inputs = holder.querySelectorAll('[data-sname]');
          inputs[type === 'FT' ? inputs.length-1 : inputs.length-2]?.focus();
        };
      }
      draw();
    };
  }

  function resetFind(reopen) {
    const idx = TOPICS.findIndex(t => t.type === 'find');
    if (idx < 0) return;
    const d = read(idx);
    for (const field of ['item','place','notes','foundBy']) d[field] = '';
    d.date = todayDate(); d.time = nowTime(); d.who = '';
    persist(idx,d);
    if (reopen && current === idx) {
      open(idx);
      // O site original escolhe Souza Lima ao abrir. A ficha nova não assume empresa.
      d.who = '';
      const company = $('f-who');
      if (company) company.value = '';
      persist(idx,d);
      updatePreview(d);
    }
  }

  window.bindFields = function (d) {
    bindBefore.call(this,d);
    if (getTopic(current) === 'movement') {
      const showPeriod = () => {
        const day = period(d) === 'DIURNO';
        const parity = $('atm-parity-field');
        if (parity) parity.hidden = !day;
        const labels = shiftLabels(d);
        const sectors = [['entries12',labels.a],['entries6',labels.b],['entriesGalpao',labels.c]];
        sectors.forEach(([key,name]) => {
          const el = document.querySelector('[data-sector="' + key + '"] .movement-sector-head strong');
          if (el) el.textContent = name;
        });
      };
      $('f-period')?.addEventListener('change',showPeriod);
      $('f-parity')?.addEventListener('change',showPeriod);
      showPeriod();
    }
    if (getTopic(current) === 'find') {
      $('atm-new-found')?.addEventListener('click',() => resetFind(true));
    }
  };

  // Envia o texto atual e inicia uma ficha em branco, sem reutilizar o achado anterior.
  const share = $('whatsAppBtn');
  if (share) {
    const before = share.onclick;
    share.onclick = function (ev) {
      const wasFind = getTopic(current) === 'find';
      if (typeof before === 'function') before.call(this,ev);
      if (wasFind) resetFind(true);
    };
  }
  const download = $('downloadBtn');
  if (download) {
    const before = download.onclick;
    download.onclick = function (ev) {
      const wasFind = getTopic(current) === 'find';
      if (typeof before === 'function') before.call(this,ev);
      if (wasFind) resetFind(true);
    };
  }
  const copyAndClose = $('copyCloseBtn');
  if (copyAndClose) {
    const before = copyAndClose.onclick;
    copyAndClose.onclick = function (ev) {
      const wasFind = getTopic(current) === 'find';
      if (typeof before === 'function') before.call(this,ev);
      if (wasFind) resetFind(false);
    };
  }
})();
