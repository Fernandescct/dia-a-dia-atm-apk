(function () {
  'use strict';
  if (window.__atmFindV2) return;
  if (typeof window.renderForm !== 'function' ||
      typeof window.whatsappFormatted !== 'function') return;
  window.__atmFindV2 = true;

  const previousRender = window.renderForm;
  const previousMessage = window.whatsappFormatted;

  // A alteração só alcança a tela Achados e Perdidos.
  window.renderForm = function (index, draft) {
    const html = previousRender.call(this, index, draft);
    if (typeof TOPICS !== 'undefined' && TOPICS[index]?.type !== 'find') return html;
    if (typeof TOPICS === 'undefined' && index !== 0) return html;

    const labelBefore = '<div class="field"><label for="f-who">Responsável pelo registro</label>';
    if (!html.includes(labelBefore)) return html;

    const foundBy = '<div class="field"><label for="f-foundBy">Quem encontrou</label>' +
      '<input id="f-foundBy" data-key="foundBy" type="text" value="' +
      escapeHTML(draft.foundBy || '') + '" placeholder="Nome de quem encontrou"></div>';
    return html.replace(labelBefore,
      foundBy + '<div class="field"><label for="f-who">Empresa</label>');
  };

  window.whatsappFormatted = function (index, draft) {
    if (typeof TOPICS !== 'undefined' && TOPICS[index]?.type !== 'find') {
      return previousMessage.call(this, index, draft);
    }
    if (typeof TOPICS === 'undefined' && index !== 0) {
      return previousMessage.call(this, index, draft);
    }

    const val = (value, placeholder) => String(value ?? '').trim() || placeholder;
    const company = String(draft.who || '').replace(/[()]/g, '').trim();
    const note = String(draft.notes || '').trim();

    return [
      '*Achados e perdidos*',
      '',
      'Item: ' + val(draft.item, '[descrever objeto]') + (note ? ' obs: ' + note : ''),
      'Data: ' + dateBR(draft.date),
      'Hora: ' + val(draft.time, nowTime()),
      'Local: ' + val(draft.place, '[informar local]'),
      'Achado por: ' + val(draft.foundBy, '[informar quem encontrou]'),
      'Empresa: ' + val(company, '[informar empresa]')
    ].join('\n');
  };

  // Reabre apenas esta tela se ela já estiver aberta no fim do carregamento.
  if (typeof current !== 'undefined' && current >= 0 &&
      typeof TOPICS !== 'undefined' && TOPICS[current]?.type === 'find' &&
      typeof open === 'function') {
    open(current);
  }
})();
