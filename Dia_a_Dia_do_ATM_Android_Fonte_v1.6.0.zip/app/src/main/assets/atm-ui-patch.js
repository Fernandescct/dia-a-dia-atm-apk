/* Correções de uso no celular: busca de colaboradores sem popup nativo sobre o teclado. */
(function () {
  'use strict';
  if (window.__atmMobileUI || typeof roster !== 'function') return;
  const area = document.getElementById('form-area');
  if (!area) return;
  window.__atmMobileUI = true;

  const css = document.createElement('style');
  css.textContent = `
    .atm-inline-directory {
      position: relative;
      z-index: 2;
      display: grid;
      gap: 3px;
      margin: 7px 0 4px;
      padding: 5px;
      max-height: 166px;
      overflow-y: auto;
      overscroll-behavior: contain;
      background: #0b1a2a;
      border: 1px solid #317a82;
      border-radius: 12px;
      box-shadow: 0 4px 12px #0005;
    }
    .atm-directory-choice {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: center;
      gap: 2px;
      width: 100%;
      min-height: 44px;
      margin: 0;
      padding: 7px 10px;
      text-align: left;
      color: #eafafa;
      background: #142e3e;
      border: 1px solid #245060;
      border-radius: 8px;
      font: 600 14px system-ui, sans-serif;
      cursor: pointer;
    }
    .atm-directory-choice small { color: #a3cdd0; font-size: 12px; font-weight: 400; }
    .atm-directory-choice:focus, .atm-directory-choice:active {
      background: #21515b;
      outline: 2px solid #55c9be;
    }
  `;
  document.head.appendChild(css);

  const normalize = value => String(value || '').normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '').trim().toLocaleUpperCase('pt-BR');
  const eligible = el => el && el.tagName === 'INPUT' && (
    el.hasAttribute('data-person') || el.hasAttribute('data-sname') ||
    el.id === 'f-name' || el.id === 'f-coverName');

  function removeNativeList() {
    area.querySelectorAll('input[list]').forEach(input => {
      if (eligible(input)) {
        input.removeAttribute('list');
        input.setAttribute('autocomplete', 'off');
      }
    });
  }

  function close() {
    area.querySelectorAll('.atm-inline-directory').forEach(el => el.remove());
  }

  function matchesFor(value) {
    const query = normalize(value);
    if (query.length < 2) return [];
    const people = roster().filter(person => String(person.name || '').trim());
    // Um nome já escolhido não deve disparar uma lista de pessoas sem relação.
    if (people.some(person => normalize(person.name) === query)) return [];
    return people.filter(person => normalize(person.name).includes(query))
      .sort((a, b) => {
        const aStarts = normalize(a.name).startsWith(query) ? 0 : 1;
        const bStarts = normalize(b.name).startsWith(query) ? 0 : 1;
        return aStarts - bStarts || a.name.localeCompare(b.name, 'pt-BR');
      }).slice(0, 3);
  }

  function show(input) {
    close();
    if (!eligible(input) || !input.isConnected) return;
    const found = matchesFor(input.value);
    if (!found.length) return;
    const field = input.closest('.field');
    if (!field) return;
    const list = document.createElement('div');
    list.className = 'atm-inline-directory';
    list.setAttribute('role', 'listbox');
    list.setAttribute('aria-label', 'Sugestões de colaboradores');
    for (const person of found) {
      const choice = document.createElement('button');
      choice.type = 'button';
      choice.className = 'atm-directory-choice';
      const name = document.createElement('span');
      name.textContent = person.name;
      const re = document.createElement('small');
      re.textContent = 'RE: ' + (person.re || 'não informado');
      choice.append(name, re);
      choice.onclick = () => {
        input.value = person.name;
        // Atualiza o RE e a escala pelos eventos já existentes no app.
        input.dispatchEvent(new Event('input', {bubbles: true}));
        close();
      };
      list.appendChild(choice);
    }
    field.appendChild(list);
  }

  area.addEventListener('focusin', ev => {
    if (eligible(ev.target)) {
      ev.target.removeAttribute('list');
      show(ev.target);
    } else close();
  });
  area.addEventListener('input', ev => {
    if (eligible(ev.target)) show(ev.target);
  });
  area.addEventListener('focusout', ev => {
    if (eligible(ev.target)) {
      setTimeout(() => {
        if (!area.contains(document.activeElement) ||
            !eligible(document.activeElement)) close();
      }, 180);
    }
  });
  document.addEventListener('click', ev => {
    if (!ev.target.closest('.atm-inline-directory') && !eligible(ev.target)) close();
  });

  // As linhas FA/FT são recriadas a cada inclusão; bloqueia nelas também
  // o seletor enorme do datalist antes que o usuário toque no campo.
  new MutationObserver(removeNativeList).observe(area, {
    subtree: true, childList: true, attributes: true, attributeFilter: ['list']
  });
  removeNativeList();
})();
